# Contact Management System

## Overview

A console-based Contact Management System built in C# / .NET as
**Task 03** of the ArithMatrix Virtual Internship Program (AVIP)
2026, Software Development track. It lets a user add, view, list,
search, edit, and delete contacts, storing them persistently in a
local JSON file so that data survives an application restart.

## AVIP Task

Task 03 — Contact Management System

## Features

Official AVIP requirements implemented:

- Add contact
- View a specific contact
- List all contacts
- Search / filter contacts by name, phone, or email
- Edit an existing contact
- Delete a contact (with confirmation)
- Input validation (name, phone, email)
- Duplicate handling (by phone and by email)
- Persistent storage in a JSON file

`[ENGINEERING ENHANCEMENT]` Search across all fields at once, in
addition to the required per-field search.

## Technology Stack

- **C# 12 / .NET 8 (LTS)** — .NET 8 is the current Long-Term-Support
  release at the time of writing, so it will keep receiving security
  updates for years, which matters for anything meant to be reused or
  reviewed later.
- **Console Application** — matches the AVIP requirement; no web or
  desktop UI framework is used.
- **`System.Text.Json`** — .NET's built-in JSON library. It ships
  with the runtime, so no third-party package (e.g. Newtonsoft.Json)
  is required for a data shape this simple.
- **xUnit** — the test framework used for the automated test project
  (`ContactManagement.Tests`).
- No ASP.NET Core, no Entity Framework Core, no ORM, no DI container,
  no CLI parsing framework — none of these provide meaningful value
  for a single-user console address book, and adding them would only
  make the project harder to learn from.

## Requirements

- .NET 8 SDK
- A terminal (PowerShell, Command Prompt, or the VS Code terminal on
  Windows; any shell on Linux/macOS)
- Git

## Project Structure

```
Task_03_Contact_Management/
│
├── src/
│   └── ContactManagement/
│       ├── Models/
│       │   └── Contact.cs
│       ├── Services/
│       │   ├── ContactService.cs
│       │   ├── SearchField.cs
│       │   └── ServiceResult.cs
│       ├── Validation/
│       │   ├── ContactValidator.cs
│       │   └── ValidationResult.cs
│       ├── Persistence/
│       │   ├── IContactRepository.cs
│       │   ├── JsonContactRepository.cs
│       │   └── PersistenceException.cs
│       ├── UI/
│       │   ├── ConsoleMenu.cs
│       │   └── ConsoleInputHelper.cs
│       ├── Program.cs
│       └── ContactManagement.csproj
│
├── tests/
│   └── ContactManagement.Tests/
│       ├── ContactServiceTests.cs
│       ├── ContactValidatorTests.cs
│       ├── JsonContactRepositoryTests.cs
│       ├── TestDoubles/
│       │   └── InMemoryContactRepository.cs
│       └── ContactManagement.Tests.csproj
│
├── data/
│   └── (contacts.json is created here automatically at runtime)
│
├── examples/
│   └── sample_contacts.json
│
├── screenshots/
│
├── README.md
├── .gitignore
├── NuGet.Config
└── ContactManagement.sln
```

## Architecture

| Layer | Class | Responsibility |
|---|---|---|
| Model | `Contact` | Pure data holder for one contact (Id, FullName, Phone, Email). |
| Validation | `ContactValidator` | Decides whether raw input is acceptable, and normalizes values for storage vs. comparison. |
| Persistence | `IContactRepository` | Abstraction over "load all / save all contacts", so business logic never depends on JSON directly. |
| Persistence | `JsonContactRepository` | Implements `IContactRepository` using a JSON file and `System.Text.Json`. |
| Business logic | `ContactService` | Owns CRUD operations, duplicate policy, and search; the only class that combines validation with persistence. |
| UI | `ConsoleMenu` / `ConsoleInputHelper` | Reads input, calls `ContactService`, prints results. Contains no business rules. |
| Composition root | `Program.cs` | The one place that wires concrete classes together (`JsonContactRepository`, `ContactService`, `ConsoleMenu`). |

The architecture deliberately avoids generic repositories, CQRS,
MediatR, domain events, or a DI container — none of these are
justified for a project of this size. `IContactRepository` is the
only abstraction introduced, and it exists specifically so that
`ContactService` can be unit-tested with an in-memory test double
instead of touching the real file system.

## Storage

- **Location:** `data/contacts.json`, relative to the working
  directory the application is run from. No absolute or
  machine-specific path is ever hard-coded, so the project works
  immediately after cloning on any machine.
- **Format:** a JSON array of contact objects, indented for
  readability:

  ```json
  [
    {
      "id": 1,
      "fullName": "John Doe",
      "phone": "01001234567",
      "email": "john.doe@example.com"
    }
  ]
  ```

- **Persistence behavior:** the full contact list is loaded once at
  startup and saved again after every successful add, edit, or
  delete. Saving uses a write-to-temp-file-then-replace strategy so
  the real file is never left half-written if the application is
  interrupted mid-save.
- **Missing file / missing directory:** treated as "no contacts yet"
  — both are created automatically the first time contacts are
  saved. This is normal, not an error.
- **Empty file:** treated the same as "no contacts yet".
- **Malformed JSON:** treated as a fatal, reported error. The
  application prints a clear message and exits *without* modifying
  the file. This is intentional: silently starting from an empty list
  would mean the very next save overwrites — and permanently
  destroys — the user's real (but corrupted) data.
- **Optional custom path:** `dotnet run -- --data <path>` can point
  the application at a different data file, useful for demos or
  testing without touching the default file.

## Validation

- **Full Name:** required, cannot be empty or whitespace-only,
  maximum 100 characters. Any script/character set is accepted
  (Arabic, accented letters, hyphens, apostrophes, etc.) — names are
  never rejected purely for their character set.
- **Phone:** required; only digits, spaces, hyphens, and an optional
  leading `+` are accepted; the digit count must be between 7 and 15.
  This intentionally does **not** implement full international
  telephone-number validation, which would need a much heavier
  library than this task warrants.
- **Email:** required, maximum 254 characters, must match the
  practical pattern `something@something.something` with no spaces.
  This is not a complete implementation of the email specification —
  it is deliberately just strict enough to reject obviously malformed
  input without rejecting real addresses.

## Duplicate Handling

A new or edited contact is rejected as a duplicate if **either**:

- its normalized email matches an existing contact's normalized
  email (comparison is trimmed and case-insensitive), **or**
- its normalized phone matches an existing contact's normalized
  phone (comparison strips spaces and hyphens, so `0100 123 4567`
  and `0100-123-4567` are recognized as the same number).

When **editing** a contact, that same contact is excluded from the
duplicate comparison, so leaving a field unchanged never triggers a
false "duplicate of itself" error.

## Search

- **Fields:** name, phone, email, and (`[ENGINEERING ENHANCEMENT]`)
  all fields at once.
- **Name / email:** case-insensitive partial (substring) match.
- **Phone:** matched against the normalized (digits-only)
  representation, so formatting differences between the stored value
  and the search query do not prevent a match.
- Search is a simple in-memory `O(N)` scan over the contact list,
  which is entirely appropriate for a small local address book —
  there is no reason to add indexing or a database for this scale.

## Installation

```powershell
git clone <repository-url>
cd SD_AVIP_2026_byte
cd Task_03_Contact_Management
dotnet restore
dotnet build
```

## Run

```powershell
dotnet run --project src/ContactManagement/ContactManagement.csproj
```

## Test

```powershell
dotnet test
```

## Publish

```powershell
dotnet publish src/ContactManagement/ContactManagement.csproj -c Release
```

This produces an optimized, self-contained build under
`src/ContactManagement/bin/Release/net8.0/publish/`, suitable for
running without the full SDK installed (a compatible .NET runtime is
still required unless a self-contained/single-file publish is
configured).

## Usage Examples

All sample data below is fictional.

### Add Contact

```
Full Name: John Doe
Phone: 01001234567
Email: john.doe@example.com
```
Expected: `Contact added successfully (Id 1).`

### List Contacts

```
Id    Name                      Phone              Email
------------------------------------------------------------------------------
1     John Doe                  01001234567        john.doe@example.com
```

### Search Contacts

```
Search text: john
Id    Name                      Phone              Email
------------------------------------------------------------------------------
1     John Doe                  01001234567        john.doe@example.com
```

### Edit Contact

```
Full Name [John Doe]:
Phone [01001234567]:
Email [john.doe@example.com]: john.doe.new@example.com
```
Expected: `Contact updated successfully.`

### Delete Contact

```
Are you sure you want to delete "John Doe"? (y/n): y
```
Expected: `Contact deleted successfully.`

### Duplicate Handling

```
Could not add contact: A contact with this phone number already exists ('John Doe', Id 1).
```

### Invalid Input

```
Could not add contact: Email address is not in a valid format (expected something like 'name@domain.com').
```

## Screenshots / Demo

See the "Screenshot Plan" and "Demo Script" sections of the main
response for exactly which screens to capture and why. Captured
images should be placed in `screenshots/`.

## Future Improvements

The following are explicitly **not** implemented in this task and
are only ideas for later:

- SQLite persistence instead of / in addition to JSON
- An ASP.NET Core Web API and/or web UI
- Authentication and multi-user support
- Cloud synchronization
- Pagination for very large contact lists
- Audit logging of changes

## Sample Data Disclaimer

All data in `examples/sample_contacts.json` and everywhere in this
README is fictional. No real personal contact information is used or
stored anywhere in this project.
